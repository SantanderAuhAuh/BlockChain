from django.apps import AppConfig


class SupplychainappConfig(AppConfig):
    name = 'SupplyChainApp'
