from django.shortcuts import render, redirect
from django.http import HttpResponse
from . import models
from .connect import ABI

abi = ABI()

companys = []

def index(request):
    companys.clear()
    companys_num = abi.getCompanysNum()[0]
    for i in range(companys_num):
        company = {}
        company['id'] = i
        company['name'] = abi.getDebtorByIndex(i)[0]
        company['receipts'] = []
        creditors_num = abi.getCreditorsNumberByDebtorIndex(i)[0]
        for j in range(creditors_num):
            receipt = abi.getCreditorsNameByDebtorIndexAndCreditorIndex(i, j)
            company['receipts'].append({'name':receipt[0],'money':receipt[1]})
        companys.append(company)
    return render(request, 'index.html', {'companys': companys})

def detail_page(request, company_id):
    company_id = int(company_id)
    receipts = companys[company_id]['receipts']
    print(receipts)
    return render(request, 'detail.html', {'receipts': receipts})   

def buy_something_page(request):
    
    return render(request, 'buy_something.html')

def buy_something(request):
    buyer = request.GET['buyer']
    seller = request.GET['seller']
    money = int(request.GET['money'])
    time = int(request.GET['time'])
    print(buyer, seller, money, time)
    abi.buySomething(buyer, seller, money, time)
    return redirect('/SupplyChainApp/index/')

def assign_claim_page(request):
    
    return render(request, 'assign_claim.html')

def assign_claim(request):
    creditor = request.GET['creditor']
    debtor = request.GET['debtor']
    receiver = request.GET['receiver']
    money = int(request.GET['money'])
    abi.assignedClaim(creditor, debtor, receiver, money)
    return redirect('/SupplyChainApp/index/')

def financing_page(request):
    
    return render(request, 'financing.html')

def finance(request):
    creditor = request.GET['creditor']
    debtor = request.GET['debtor']
    financeInstitution = request.GET['financeInstitution']
    money = int(request.GET['money'])
    abi.finacing(creditor, debtor, financeInstitution, money)
    return redirect('/SupplyChainApp/index/')

def repay_debt_page(request):
    
    return render(request, 'repay_debt.html')

def repay_debt(request):
    creditor = request.GET['creditor']
    debtor = request.GET['debtor']
    money = int(request.GET['money'])
    abi.repay(debtor, creditor, money)
    return redirect('/SupplyChainApp/index/')
