import sys
sys.path.insert(0, '/home/fisco-bcos/fisco/python-sdk/')

from client.contractnote import ContractNote
from client.bcosclient import BcosClient
import os
from eth_utils import to_checksum_address
from client.datatype_parser import DatatypeParser
from client.common.compiler import Compiler
from client.bcoserror import BcosException, BcosError
from client_config import client_config


# 从文件加载abi定义
if os.path.isfile(client_config.solc_path) or os.path.isfile(client_config.solcjs_path):
    Compiler.compile_file("/home/fisco-bcos/fisco/python-sdk/contracts/SupplyChain1.sol")
abi_file = "/home/fisco-bcos/fisco/python-sdk/contracts/SupplyChain1.abi"
data_parser = DatatypeParser()
data_parser.load_abi_file(abi_file)
contract_abi = data_parser.contract_abi
to_address = "0xb7a506877cd874b0dc0ed1a43762193b60a7b6d4"

class ABI:

    def __init__(self):
        self.client = BcosClient()
        print(self.client.getinfo())

    def __del__(self):
        print("demo_tx,total req {}".format(self.client.request_counter))
        self.client.finish()
       
    def getCompanysNum(self):
        receipt = self.client.sendRawTransactionGetReceipt(to_address,contract_abi,"getCompanysNum", [0])
        res = self.client.call(to_address, contract_abi, "getCompanysNum", [0])
        print("call getCompanysNum result:", res)
        return res

    def getDebtorByIndex(self, debtorIndex):
        receipt = self.client.sendRawTransactionGetReceipt(to_address,contract_abi, "getDebtorByIndex", [debtorIndex])
        res = self.client.call(to_address, contract_abi, "getDebtorByIndex", [debtorIndex])
        print("call getDebtorByIndex result:", res)
        return res
    
    def getCreditorsNumberByDebtorIndex(self, debtorIndex):
        receipt = self.client.sendRawTransactionGetReceipt(to_address,contract_abi, "getCreditorsNumberByDebtorIndex", [debtorIndex])
        res = self.client.call(to_address, contract_abi, "getCreditorsNumberByDebtorIndex", [debtorIndex])
        print("call getCreditorsNumberByDebtorIndex result:", res)
        return res
    
    def getCreditorsNameByDebtorIndexAndCreditorIndex(self, debtorIndex, creditorIndex):
        receipt = self.client.sendRawTransactionGetReceipt(to_address,contract_abi,"getCreditorsNameByDebtorIndexAndCreditorIndex", [debtorIndex, creditorIndex])
        res = self.client.call(to_address, contract_abi, "getCreditorsNameByDebtorIndexAndCreditorIndex", [debtorIndex, creditorIndex])
        print("call getCreditorsNameByDebtorIndexAndCreditorIndex result:", res)
        return res

    def buySomething(self, debtor, creditor, money, time):
        receipt = self.client.sendRawTransactionGetReceipt(to_address,contract_abi, "buySomething", [debtor, creditor, money, time])
        print("receipt:",receipt)
        res = self.client.call(to_address, contract_abi, "buySomething", [debtor, creditor, money, time])
        print("call buySomething result:", res)
        return res

    def assignedClaim(self, creditor, debtor, reciever, money):
        receipt = self.client.sendRawTransactionGetReceipt(to_address,contract_abi, "assignedClaim", [creditor, debtor, reciever, money])
        res = self.client.call(to_address, contract_abi, "assignedClaim", [creditor, debtor, reciever, money])
        print("call assignedClaim result:", res)
        return res
    
    def finacing(self, creditor, debtor, financeInstitution, money):
        receipt = self.client.sendRawTransactionGetReceipt(to_address,contract_abi, "financing", [debtor, creditor, financeInstitution, money])
        res = self.client.call(to_address, contract_abi, "financing", [debtor, creditor, financeInstitution, money])
        print("call finacing result:", res)
        return res

    def repay(self, debtor, creditor, money):
        receipt = self.client.sendRawTransactionGetReceipt(to_address,contract_abi, "repay", [debtor, creditor, money])
        res = self.client.call(to_address, contract_abi, "repay", [debtor, creditor, money])
        print("call repay result:", res)
        return res

