from django.conf.urls import url, include
from . import views

urlpatterns = [
    url(r'^index/', views.index),
    url(r'^detail/(?P<company_id>[0-9]+)$', views.detail_page),
    url(r'^buySomething/', views.buy_something_page),
    url(r'^assignClaim/', views.assign_claim_page),
    url(r'^financing/', views.financing_page),
    url(r'^repayDebt/', views.repay_debt_page),
]

